"""
to run live - http://127.0.0.1:5000/ (in browser)
"""


from flask import Flask, render_template, request, redirect, url_for, flash, session
from db import get_db_connection
from werkzeug.security import check_password_hash
from functools import wraps
from datetime import date, timedelta
 

app = Flask(__name__)
app.secret_key = 'Spookie'  # real secret key

app.permanent_session_lifetime = timedelta(days=7)


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.")
            return redirect(url_for("home"))
        return f(*args, **kwargs)
    return decorated_function

def format_time(value):
    if isinstance(value, timedelta):
        total_seconds = int(value.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        return f"{hours:02d}:{minutes:02d}"
    return str(value)[:5]

@app.route("/")
def home():
    return render_template("login.html")

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username")
    password = request.form.get("password")
    remember = request.form.get("remember")

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE Username = %s", (username,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()

    if user and check_password_hash(user["PasswordHash"], password):
        session["user_id"] = user["UserID"]
        session["full_name"] = user["FullName"]
        session["role"] = user["Role"]
        session.permanent = True if remember else False
        return redirect(url_for("dashboard"))
    else:
        flash("Login failed. Invalid username or password.")
        return redirect(url_for("home"))

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.")
    return redirect(url_for("home"))

@app.route("/forgot-password")
def forgot_password():
    return render_template("forgot_password.html")


@login_required
@app.route("/patients", methods=["GET", "POST"])
def patients():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        id_number = request.form.get("id_number")
        dob = request.form.get("dob")  # format: YYYY-MM-DD

        if not id_number or len(id_number) < 6 or not id_number[0:6].isdigit():
            flash("ID number must start with at least 6 digits (YYMMDD).")
        else:
            yy = id_number[0:2]
            mm = id_number[2:4]
            dd = id_number[4:6]

            current_yy = date.today().year % 100
            century = "20" if int(yy) <= current_yy else "19"
            expected_dob = f"{century}{yy}-{mm}-{dd}"

            if dob != expected_dob:
                flash(f"Date of birth doesn't match the ID number. Expected {expected_dob}.")
            else:
                try:
                    cursor.execute("SELECT PatientNumber FROM patients ORDER BY PatientNumber DESC LIMIT 1")
                    last = cursor.fetchone()

                    if last:
                        next_number = int(last["PatientNumber"]) + 1
                    else:
                        next_number = 1

                    new_patient_number = str(next_number).zfill(8)

                    cursor.execute("""
                        INSERT INTO patients
                        (PatientNumber, FirstName, LastName, IDNumber, DateOfBirth, Gender, ContactNumber, Email,
                         ResidentialAddress, MedicalAidProvider, MedicalAidNumber, EmergencyContact,
                         Language, Allergies, ChronicConditions, BloodType, MaritalStatus)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                        new_patient_number,
                        request.form.get("first_name"),
                        request.form.get("last_name"),
                        id_number,
                        dob,
                        request.form.get("gender"),
                        request.form.get("contact_number"),
                        request.form.get("email"),
                        request.form.get("address"),
                        request.form.get("medical_aid_provider"),
                        request.form.get("medical_aid_number"),
                        request.form.get("emergency_contact"),
                        request.form.get("language"),
                        request.form.get("allergies"),
                        request.form.get("chronic_conditions"),
                        request.form.get("blood_type"),
                        request.form.get("marital_status"),
                    ))
                    conn.commit()
                    flash("Patient registered successfully!")
                except Exception as e:
                    flash(f"Could not save patient: {e}")

    search = request.args.get("search")
    if search:
        like_pattern = f"%{search}%"
        cursor.execute("""
            SELECT * FROM patients
            WHERE FirstName LIKE %s OR LastName LIKE %s OR IDNumber LIKE %s OR PatientNumber LIKE %s
        """, (like_pattern, like_pattern, like_pattern, like_pattern))
    else:
        cursor.execute("SELECT * FROM patients ORDER BY RegistrationDate DESC")

    all_patients = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template("patients.html", patients=all_patients, search=search)

@login_required
@app.route("/appointments", methods=["GET", "POST"])
@login_required
def appointments():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        patient_number = request.form.get("patient_number")
        doctor_id = request.form.get("doctor_id")
        notes = request.form.get("notes")
        appt_date = request.form.get("appt_date")
        appt_time = request.form.get("appt_time")

        cursor.execute("""
            SELECT * FROM appointments
            WHERE DoctorID = %s AND AppointmentDate = %s AND AppointmentTime = %s
        """, (doctor_id, appt_date, appt_time))
        clash = cursor.fetchone()

        if clash:
            flash("This doctor is already booked for that date and time.")
        else:
            cursor.execute("""
                INSERT INTO appointments
                (AppointmentDate, AppointmentTime, DoctorID, PatientNumber, AppointmentStatus, Notes)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (appt_date, appt_time, doctor_id, patient_number, "Scheduled", notes))
            conn.commit()
            flash("Appointment booked successfully!")

    search_id = request.args.get("id_number", "")
    found_patient = None
    if search_id:
        cursor.execute("SELECT * FROM patients WHERE IDNumber = %s", (search_id,))
        found_patient = cursor.fetchone()

    specialization = request.args.get("specialization", "")
    cursor.execute("SELECT DISTINCT Specialization FROM doctors ORDER BY Specialization")
    specializations = [row["Specialization"] for row in cursor.fetchall()]

    if specialization:
        cursor.execute("SELECT * FROM doctors WHERE Specialization = %s", (specialization,))
    else:
        cursor.execute("SELECT * FROM doctors")
    doctors = cursor.fetchall()

    selected_doctor = request.args.get("doctor_id", "")
    selected_date = request.args.get("appt_date", "")
    booked_times = []
    if selected_doctor and selected_date:
        cursor.execute("""
            SELECT AppointmentTime FROM appointments
            WHERE DoctorID = %s AND AppointmentDate = %s
            ORDER BY AppointmentTime
        """, (selected_doctor, selected_date))
        booked_times = [str(row["AppointmentTime"]) for row in cursor.fetchall()]

    cursor.execute("""
        SELECT a.AppointmentNumber, a.AppointmentDate, a.AppointmentTime, a.AppointmentStatus, a.Notes,
               CONCAT(p.FirstName, ' ', p.LastName) AS PatientName,
               d.FullName AS DoctorName
        FROM appointments a
        JOIN patients p ON a.PatientNumber = p.PatientNumber
        JOIN doctors d ON a.DoctorID = d.DoctorID
        ORDER BY a.AppointmentDate DESC, a.AppointmentTime DESC
    """)
    all_appointments = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "appointments.html",
        found_patient=found_patient,
        search_id=search_id,
        doctors=doctors,
        specializations=specializations,
        specialization=specialization,
        selected_doctor=selected_doctor,
        selected_date=selected_date,
        booked_times=booked_times,
        appointments=all_appointments
    )

@login_required
@app.route("/dashboard")
@login_required
def dashboard():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT COUNT(*) AS count FROM appointments WHERE AppointmentDate = CURDATE()")
    today_count = cursor.fetchone()["count"]

    cursor.execute("SELECT COUNT(*) AS count FROM patients")
    patient_count = cursor.fetchone()["count"]

    cursor.execute("SELECT COUNT(*) AS count FROM doctors")
    doctor_count = cursor.fetchone()["count"]

    cursor.execute("""
        SELECT COUNT(*) AS count FROM appointments
        WHERE AppointmentDate > CURDATE() AND AppointmentDate <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
    """)
    upcoming_count = cursor.fetchone()["count"]

    cursor.execute("""
        SELECT a.AppointmentTime, a.AppointmentStatus,
               CONCAT(p.FirstName, ' ', p.LastName) AS PatientName,
               d.FullName AS DoctorName
        FROM appointments a
        JOIN patients p ON a.PatientNumber = p.PatientNumber
        JOIN doctors d ON a.DoctorID = d.DoctorID
        WHERE a.AppointmentDate = CURDATE()
        ORDER BY a.AppointmentTime ASC
    """)
    todays_appointments = cursor.fetchall()

    cursor.execute("SELECT COUNT(*) AS count FROM patients WHERE DATE(RegistrationDate) = CURDATE()")
    new_patients_today = cursor.fetchone()["count"]

    cursor.execute("""
        SELECT COUNT(*) AS count FROM appointments
        WHERE AppointmentDate = CURDATE() AND AppointmentStatus = 'No-show'
    """)
    no_show_count = cursor.fetchone()["count"]

    cursor.execute("""
        SELECT a.AppointmentTime, d.FullName AS DoctorName
        FROM appointments a
        JOIN doctors d ON a.DoctorID = d.DoctorID
        WHERE a.AppointmentDate = CURDATE() AND a.AppointmentTime > CURTIME()
        ORDER BY a.AppointmentTime ASC
        LIMIT 1
    """)
    next_appointment = cursor.fetchone()

    cursor.close()
    conn.close()

    today_display = date.today().strftime("%d %B %Y")

    return render_template(
        "dashboard.html",
        today_count=today_count,
        patient_count=patient_count,
        doctor_count=doctor_count,
        upcoming_count=upcoming_count,
        today=today_display,
        appointments=todays_appointments,
        new_patients_today=new_patients_today,
        no_show_count=no_show_count,
        next_appointment=next_appointment
    )

if __name__ == "__main__":
    app.run(debug=True)