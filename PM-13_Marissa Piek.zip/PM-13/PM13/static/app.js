document.addEventListener("DOMContentLoaded", function () {
  const steps = document.querySelectorAll(".form-step");
  const circles = document.querySelectorAll(".step-circle");
  const labels = document.querySelectorAll(".step-label");
  const connectors = document.querySelectorAll(".step-connector");

  function goToStep(stepNumber) {
    steps.forEach(step => {
      step.classList.toggle("active", step.dataset.step === String(stepNumber));
    });

    circles.forEach(circle => {
      const n = Number(circle.dataset.circle);
      circle.classList.toggle("active", n === stepNumber);
      circle.classList.toggle("completed", n < stepNumber);
      circle.textContent = n < stepNumber ? "✓" : n;
    });

    labels.forEach(label => {
      label.classList.toggle("active", Number(label.dataset.label) === stepNumber);
    });

    connectors.forEach(connector => {
      connector.classList.toggle("completed", Number(connector.dataset.connector) < stepNumber);
    });
  }

  document.querySelectorAll(".wizard-next").forEach(button => {
    button.addEventListener("click", function () {
      const currentStep = this.closest(".form-step");
      const requiredFields = currentStep.querySelectorAll("[required]");
      let allValid = true;

      requiredFields.forEach(field => {
        if (!field.reportValidity()) {
          allValid = false;
        }
      });

      if (allValid) {
        goToStep(Number(this.dataset.next));
      }
    });
  });

  document.querySelectorAll(".wizard-back").forEach(button => {
    button.addEventListener("click", function () {
      goToStep(Number(this.dataset.back));
    });
  });

  goToStep(1);
});


