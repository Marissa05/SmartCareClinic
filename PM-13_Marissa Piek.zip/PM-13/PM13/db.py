import mysql.connector

def get_db_connection():
    connection = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="smartcareclinic"
    )
    return connection

if __name__ == "__main__":
    conn = get_db_connection()
    print("Connected successfully!" if conn.is_connected() else "Connection failed")
    conn.close()